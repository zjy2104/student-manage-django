from django.apps import AppConfig


class StumanageConfig(AppConfig):
    name = 'stumanage'
