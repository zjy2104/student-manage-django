from django.urls import path
from django.conf.urls import include, url
from . import views

app_name = 'school'
urlpatterns = [
    path('the/<int:num>', views.the, name='the'),
    path('teacher/<str:username>', views.SchoolView, name='school'),
    path('student/<int:username>', views.student, name='student'),
    path('teacher/allstudent/<str:username>', views.AllstuView, name='all'),
    path('namselect/<str:username>', views.SelectnameView, name='namesel'),
    path('numselect/<str:username>', views.SelectnumView, name='numsel'),
    path('allstudent/<str:sno>', views.index, name='StaffManage'),
    path('student/student_edit/', views.student_edit, name='student_edit'),
    path('allstudent/edit_user_info_list/', views.edit_user_info_list, name='edit_user_info_list'),
    path('allstudent/delete_user_info_list/', views.delete_user_info_list, name='delete_user_info_list'),
    path('allstudent/add_user_info_list/', views.add_user_info_list, name='add_user_info_list'),
]