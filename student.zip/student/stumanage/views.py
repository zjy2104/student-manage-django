from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from .models import Person, Student
from django.shortcuts import render
from django.core.exceptions import ObjectDoesNotExist
from stumanage import models
from django.http import HttpResponse
from django.http import Http404
import traceback
from django.views.decorators.csrf import csrf_exempt
from pure_pagination import Paginator, PageNotAnInteger
import json
from django.shortcuts import redirect


def login(request):
    username = request.POST.get('username')
    passward = request.POST.get('password')
    print(username)
    print(passward)
    person = Person.objects.filter(namenum=username)
    try:
        person = Person.objects.get(namenum=username)
    except ObjectDoesNotExist:
        print("wu")
        return render(request, 'index.html')
    else:
        if person.password == passward:

            print("ok")
            if person.id == 1:
                return redirect('school:school', username)
            else:
                return redirect('school:student', username)
        else:
            print("no")
            return HttpResponse("密码错误")
    return render(request, 'index.html')






def SchoolView(request, username):
    person = Person.objects.get(namenum=username)
    context = {'teacher_name': person}
    return render(request, 'the main/school.html', context)

def student(request, username):
    username = '%07d' % (username)
    print(username)
    person = Student.objects.get(sno=username)
    context = {'student': person, 'username': username}
    return render(request, 'the main/student.html', context)

def example(sno):
    print(sno+'ok')

def AllstuView(request, username):

    stulist = Student.objects.all()
    try:
        page = request.GET.get('page', 1)
    except PageNotAnInteger:
        page = 1
    p = Paginator(stulist, per_page=11, request=request)
    number = p.page(page)
    context = {'contacts': number, 'username': username}
    return render(request, 'the main/allstudent.html', context)


def SelectnameView(request, username):
    sel_name = request.POST.get('sel_name', 'Uzi')
    print(sel_name)
    errorwar = ''
    if not sel_name:
        errorwar = 1
    studentname = Student.objects.filter(sname=sel_name)
    context = {'error': errorwar, 'data': studentname, 'username': username}
    return render(request, 'the main/nameselect.html', context)

def SelectnumView(request, username):
    sel_num = request.POST.get('sms_num')
    print(sel_num)
    errorwar = ''
    if not sel_num:
        errorwar = 1
    studentnum = Student.objects.filter(sno=sel_num)
    print(studentnum)
    context = {'error': errorwar, 'result': studentnum, 'username': username}
    return render(request, 'the main/numberselect.html', context)

def Setdata(request):

    if request.POST:
        print("jjj")
        if "set" in request.POST:
            sname = request.POST.get('set_sname')
            sno = request.POST.get('set_sno')
            ssex = request.POST.get('set_ssex')
            sage = request.POST.get('set_sage')
            scollege = request.POST.get('set_scollege')
            print("ok")
            try:
                student = Student.objects.get(sno=sno)
            except ObjectDoesNotExist:
                print("用户不存在")
            else:
                student.delete()
            person = models.Student(sno=sno, sname=sname, ssex=ssex, sage=sage, scollege=scollege)
            person.save()
        if 'delete' in request.POST:
            sno = request.POST.get('set_sno')
            print("no")
            try:
                student = Student.objects.get(sno=sno)
            except ObjectDoesNotExist:
                print("用户不存在")
            else:
                print("成功")
                student.delete()
        return HttpResponse(1)
    else:
        print("yyy")


def index(request,sno):
    print(sno)
    try:
        result = Student.objects.get(sno=sno)
    except:
        traceback.print_exc()
        raise Http404

    return render(request, 'the main/index.html', {
        'result': result,
    })

@csrf_exempt
def student_edit(request):
    json_receive = json.loads(request.body)
    #id = request.GET["sno"]
    id = json_receive['sno']
    print(2)
    id = '%07d' % (id)
    user_name = json_receive['name']
    user_sex = json_receive['sex']
    user_age = json_receive['age']
    print(user_age)
    print(id)
    user = Student.objects.get(sno=id)
    print(id + 'yes')
    user.delete()
    new_user = models.Student(sno=id, sname=user_name, ssex=user_sex, sage=user_age, scollege=user.scollege)
    new_user.save()
    return HttpResponse(1)



@csrf_exempt
def edit_user_info_list(request):
    json_receive = json.loads(request.body)
    # id = request.GET["sno"]
    id = json_receive['id']
    print(id)
    user_sno = json_receive['sno']
    user_name = json_receive['name']
    user_age = json_receive['age']
    user_sex = json_receive['sex']
    user_college = json_receive['college']

    user_id = '%07d' % (id)
    id = '%07d' % (id)
    delete_user = Student.objects.get(sno=user_id)
    delete_user.delete()
    print("jjj")
    print(id)
    try:
        user = Student.objects.get(sno=user_sno)
    except ObjectDoesNotExist:
        print(user_sno+'yes')
        new_user = models.Student(sno=user_sno, sname=user_name, ssex=user_sex, sage=user_age, scollege=user_college)
        new_user.save()
        return HttpResponse(200)
    else:
        return HttpResponse(0)

@csrf_exempt
def add_user_info_list(request):
    json_receive = json.loads(request.body)
    user_sno = json_receive['sno']
    user_name = json_receive['name']
    user_age = json_receive['age']
    user_sex = json_receive['sex']
    user_college = json_receive['college']
    try:
        user = Student.objects.get(sno=user_sno)
    except ObjectDoesNotExist:
        print(user_sno + 'yes')
        new_user = models.Student(sno=user_sno, sname=user_name, ssex=user_sex, sage=user_age, scollege=user_college)
        new_user.save()
        return HttpResponse(200)
    else:
        print("no")
        return HttpResponse(0)
    print("wancheng")
    return render(request, 'the main/the.html', {'result': num})

def the(request,num):
    print("laile")
    return render(request, 'the main/the.html', {'result': num})

@csrf_exempt
def delete_user_info_list(request):
    print("here")
    #id = request.POST.get('ID')
    json_receive = json.loads(request.body)
    # id = request.GET["sno"]
    id = json_receive['sno']
    print(id)
    user_id = '%07d' % (id)
    print("the" + user_id)
    delete_user = Student.objects.get(sno=user_id)
    user_delete = Person.objects.get(namenum=user_id)
    user_delete.delete()
    delete_user.delete()
