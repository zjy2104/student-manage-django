$(function() {


   $('#sms_add').click(function(){
       print("111000");
     $('#myModal').modal("toggle");
     $('#myModal').on("shown.bs.modal", function(){
        //$('#sm_name').val("");
        //$('#sm_sex').val("");
        //$('#sm_type').val("");
        $('#sm_sno').val("");
        $('#sm_name').val("");
        $('#sm_sex').val("");
        $('#sm_age').val("");
        $('#sm_College').val("");
        $('#myModalLabel').text('Add One Item');
      });
   });

   $('#add_ok').click(function() {
       $('#sm_sno').parent().removeClass("has-error");
       if ($('#sm_sno').val() == "") {
           $('#sm_sno').parent().addClass("has-error");
       }
       $('#sm_name').parent().removeClass("has-error");
       if ($('#sm_name').val() == "") {
           $('#sm_name').parent().addClass("has-error");
       }

       $('#sm_sex').parent().removeClass("has-error");
       if ($('#sm_sex').val() == "") {
           $('#sm_sex').parent().addClass("has-error");
       }

       $('#sm_age').parent().removeClass("has-error");
       if ($('#sm_age').val() == "") {
           $('#sm_age').parent().addClass("has-error");
       }
       $('#sm_College').parent().removeClass("has-error");
       if ($('#sm_College').val() == "") {
           $('#sm_College').parent().addClass("has-error");
       }
        var id = $('#sm_sno').val();
        var name = $('#sm_name').val();
        var sex = $('#sm_sex').val();
        var age = $('#sm_age').val();
        var college = $('#sm_College').val();
        var title = $('#myModalLabel').text();
        $.post("add_user_info_list", {"sno": id, "age": age,
            "name": name, "sex": sex, "college": college});
    });
})


    function createTable(result) {
        $.each(result, function (index, row) {
            $('#table').append(createTableLine(row));
        });
    }

    function createTableLine(row) {
        var trNode = document.createElement("tr");
        var tdnodeId = document.createElement("td");
        tdnodeId.innerHTML = row.id;
        tdnodeId.setAttribute("class", "id");

        var tdnodeName = document.createElement("td");
        tdnodeName.innerHTML = row.name;
        tdnodeName.setAttribute("class", "name");

        var tdnodeSex = document.createElement("td");
        tdnodeSex.innerHTML = row.sex;
        tdnodeSex.setAttribute("class", "sex");

        var tdnodeType = document.createElement("td");
        tdnodeType.innerHTML = row.type;
        tdnodeType.setAttribute("class", "type");

        var tdnodeBtn = document.createElement("td");
        var aNode1 = document.createElement("a");
        aNode1.setAttribute("class", "navbar-btn");
        var spanNode = document.createElement("span");
        spanNode.setAttribute("class", "glyphicon glyphicon-pencil");
        aNode1.appendChild(spanNode);
        aNode1.onclick = editStaff;
        aNode1.appendChild(spanNode);
        tdnodeBtn.appendChild(aNode1);


        var tdnodeBtn2 = document.createElement("td");
        var spanNode2 = document.createElement("span");
        var aNode2 = document.createElement("a");
        aNode2.setAttribute("class", "navbar-btn");
        spanNode2.setAttribute("class", "glyphicon glyphicon-trash");
        aNode2.onclick = deleteFun;
        aNode2.appendChild(spanNode2);
        tdnodeBtn2.appendChild(aNode2);

        trNode.appendChild(tdnodeId);
        trNode.appendChild(tdnodeName);
        trNode.appendChild(tdnodeSex);
        trNode.appendChild(tdnodeType);
        trNode.appendChild(tdnodeBtn);
        trNode.appendChild(tdnodeBtn2);
        return trNode;
    }

    function editStaff() {
        $('#myModal').modal('toggle')
        var sno = $(this).parent().parent().children(".sno").text();
        var name = $(this).parent().parent().children(".sname").text();
        var sex = $(this).parent().parent().children(".ssex").text();
        var college = $(this).parent().parent().children(".scollege").text();
        var age = $(this).parent().parent().children(".sage").text();
        $('#myModal').on("shown.bs.modal", function () {
            $('#myModalLabel').attr("name", id);
            $('#sm_sno').val(sno);
            $('#sm_name').val(name);
            $('#sm_sex').val(sex);
            $('#sm_age').val(age);
            $('#sm_College').val(college);
            $('#myModalLabel').text('Update One Item');
        });
    }

    function deleteFun() {
        var id = $(this).parent().parent().children(".sno").text();
        var node = $(this).parent().parent();

        $.post("/delete_user_info_list", {"ID": id}, function (result) {
            node.remove();
        });
    }
