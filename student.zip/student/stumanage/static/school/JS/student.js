function smsQuery(){
  var num = $('#sms_num').val();

  $.post("/SelectnumView", {"sel_num": num}, function(result){
    $.each($('#table').children(), function(index, line){
      line.remove();

    });
    createTable(result);
  });
}